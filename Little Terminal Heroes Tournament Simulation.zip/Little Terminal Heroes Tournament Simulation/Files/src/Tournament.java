/**
 *
 *  @author Niczyporuk Konrad
 *
 */

import java.util.Scanner;

public class Tournament {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(
				"\nLADIES AND GENTLEMEN!\nHUMANS AND MONSTERS!\nLETS BEGIN THE GAME!\n"+
				"\n---------------------------------------------------------------------------"
				);
		Scanner in = new Scanner(System.in);
		int play=1;
		while(play==1) {
			/*
			 * Intro to the Tournament
			 */
			System.out.println(
					"\nCHOOSE TWO OUT OF OUR HEROES\n\n"+
					"[1] VALOROUS ULRIK [KNIGHT] - HP [400] / ATK [42-64] / DEF [37]\n"+
					"[2] ONE-FANG UGRDUK [ORC] - HP [450] / ATK [30-80] / DEF [15]\n"+
					"[3] ENLIGHTENED MALIK [DRUID] - HP [335] / ATK [50-55] / DEF [24]\n"+
					"[4] ASSASSIN KHELEB [PALADIN] - HP [370] / ATK [37-73] / DEF [32]\n"+
					"\n-----------------------------------------------------------------------------------------------------------------------\n"+
					"* Knight - Light Attack (20% chance for cumulative sword attack with 200% power)\n" + 
					"* Orc - Fury (10% chance for chaotic axe attack with 260% power)\n" + 
					"* Druid - Wounds Healing (15% chance for healing 20% from max HP points or (if less needed) all points remaining to full HP)\n" + 
					"* Druid - Protective Mist (10% chace for avoiding damage in current round)\n" + 
					"* Paladin - Sudden Attack (30% chance for stab with hidden dagger.\n	Deals extra wounds of 35% MAX attack during 3 next rounds)\n" + 
					"-----------------------------------------------------------------------------------------------------------------------\n"+
					"\nWHO DO YOU CHOOSE? (Just give the Hero number, for example: 1 - if You want to choose Knight)\n\n"+
					"FIRST HERO: "
					);
			int var1 = in.nextInt();
			System.out.println("\nSECOND HERO: ");
			int var2 = in.nextInt();
			System.out.println(
					"\n---------------------------------------------------------------------\n"+
					"ALEA IACTA EST!\n"+
					"LETS BEGIN THE CLASH!\n"+
					"---------------------------------------------------------------------\n"
					);
			/*
			 * Choosing our Heroes
			 */
			Hero hero1 = null;
			Hero hero2 = null;
			switch(var1) {
				case 1:
					hero1 = new Knight();
					break;
				case 2:
					hero1 = new Orc();
					break;
				case 3:
					hero1 = new Druid();
					break;
				case 4:
					hero1 = new Paladin();
					break;
			}
			switch(var2) {
				case 1:
					hero2 = new Knight();
					break;
				case 2:
					hero2 = new Orc();
					break;
				case 3:
					hero2 = new Druid();
					break;
				case 4:
					hero2 = new Paladin();
					break;
			}
			try
			{
			    Thread.sleep(1800);
			}
			catch(InterruptedException ex)
			{
			    Thread.currentThread().interrupt();
			}
			/*
			 * Clash
			 */
			String fightPoint="fight";
			while(fightPoint=="fight") {
				System.out.println("-----> ROUND "+Fight.round+" <-----\n");
				fightPoint=Fight.fight(hero1, hero2);
				if(fightPoint=="fight") {
					try
					{
					    Thread.sleep(4300);
					}
					catch(InterruptedException ex)
					{
					    Thread.currentThread().interrupt();
					}
				}
				else if(fightPoint=="draw") {
					System.out.println("Both Heroes fell in equal fight!");
					Tournament.setCharCount(var1, hero1);
					Tournament.setCharCount(var2, hero2);
				}
				else if(fightPoint=="1") {
					System.out.println(hero1.name+" has won!\nPRAISE THE WINNER!");
					Tournament.setCharCount(var1, hero1);
					Tournament.setCharCount(var2, hero2);
				}
				else {
					System.out.println(hero2.name+" has won!\nPRAISE THE WINNER!");
					Tournament.setCharCount(var1, hero1);
					Tournament.setCharCount(var2, hero2);
				}
			}
			System.out.print(
					"\n---------------------------------------------------------------------\n"+
					"\nTHE END OF FIGHT!\n\n"+
					"DO YOU WANT ANOTHER FIGHT?\n[1] - YES!!!\n[2] - NO, END THE GAME...\n"
					); 
			play=in.nextInt();
			System.out.println(
					"\n---------------------------------------------------------------------"
					);
		}
	}
	
	public static void setCharCount(int var, Hero hero) {

		if(var==1) {
			((Knight)hero).characterCount=0;
		}
		else if(var==2) {
			((Orc)hero).characterCount=0;
		}
		else if(var==3) {
			((Druid)hero).characterCount=0;
		}
		else{
			((Paladin)hero).characterCount=0;
		}
	}
}

/**
 *
 *  @author Niczyporuk Konrad
 *
 */

public class Fight {
static int round=1;
	
	public static String fight(Hero hero1, Hero hero2) {
		hero2.defense(hero1.attack());
		hero1.defense(hero2.attack());
		System.out.println(
				"\n"+hero1.name+" - HP ["+hero1.hp+"] ----- "+hero2.name+" - HP ["+hero2.hp+"]\n"+
				"\n---------------------------------------------------------------------\n"
				);
		round+=1;
		if(hero1.hp==0 && hero2.hp==0) {
			Fight.round=1;
			return "draw";
		}
		else if(hero2.hp==0) {
			Fight.round=1;
			return "1";
		}
		else if(hero1.hp==0) {
			Fight.round=1;
			return "2";
		}
		return "fight";
	}
}

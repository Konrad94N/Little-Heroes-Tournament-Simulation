#!/bin/bash

java -cp Files/Tournament.jar Tournament

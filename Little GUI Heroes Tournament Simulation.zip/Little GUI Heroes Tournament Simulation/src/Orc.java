/**
 *
 *  @author Niczyporuk Konrad
 *
 */

public class Orc extends Hero{
	protected static int characterCount = 0;
	protected int furyCount = 2;
	TournamentTextPanel tournamentTextPanel;
	
	public Orc() {
		if(this.characterCount!=0) {
			this.name="ONE-FANG UGRDUK "+this.characterCount;
		}
		else {
			this.name="ONE-FANG UGRDUK";
		}
		this.hp=450;
		this.atkMax=80;
		this.atkMin=30;
		this.def=15;
		this.characterCount++;
	}
	
	public int attack(){
		this.furyCount++;
		double randVar = Math.random();
		if((randVar>=0.74 && randVar<0.84) || (randVar>=0.12 && randVar<0.22)) {
			tournamentTextPanel.fightText.append(this.name+" missed\n");
			return 0;
		}
		int diffAtk = this.atkMax-this.atkMin;
		int Atk = this.atkMin+(int)(((double)diffAtk)*(Math.random()+0.01));
		if(randVar>=0.67 && randVar<0.77 && this.furyCount>2) {
			this.furyCount=0;
			tournamentTextPanel.fightText.append(this.name+" exploded into Fury and dealt damage: "+(int)(Atk*2.6)+"\n");
			return (int)(Atk*2.6);
		}
		tournamentTextPanel.fightText.append(this.name+" dealt damage: "+Atk+"\n");
		return Atk;
	}
	public int defense(int atkOpp) {
		int atk = (int)(atkOpp*(((double)(100-this.def))/100));
		this.hp-=atk;
		if(this.hp<0) {
			this.hp=0;
		}
		return this.hp;
	}
}

/**
 *
 *  @author Niczyporuk Konrad
 *
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.Border;

public class HeroesToChoose extends JPanel implements ActionListener{
	
	JButton knightButton1;
	JButton orcButton1;
	JButton druidButton1;
	JButton assassinButton1;
	JButton knightButton2;
	JButton orcButton2;
	JButton druidButton2;
	JButton assassinButton2;
	JLabel firstHero = new JLabel(" Hero 1 ");
	JLabel secondHero = new JLabel(" Hero 2 ");
	ImagePanel firstHeroImg = new ImagePanel("images/questionMark.png",110,150);
	ImagePanel secondHeroImg = new ImagePanel("images/questionMark.png",110,150);
	OpeningWindow openingWindow;
	
	public HeroesToChoose(OpeningWindow openingWindow) {
		super();
		this.setSize(500,600);
		this.openingWindow = openingWindow;
			
		this.knightButton1 = new JButton("Knight");
		this.orcButton1 = new JButton("Orc");
		this.druidButton1 = new JButton("Druid");
		this.assassinButton1 = new JButton("Assassin");	
		this.knightButton2 = new JButton("Knight");
		this.orcButton2 = new JButton("Orc");
		this.druidButton2 = new JButton("Druid");
		this.assassinButton2 = new JButton("Assassin");
		
		this.knightButton1.addActionListener(this);
		this.orcButton1.addActionListener(this);
		this.druidButton1.addActionListener(this);
		this.assassinButton1.addActionListener(this);
		this.knightButton2.addActionListener(this);
		this.orcButton2.addActionListener(this);
		this.druidButton2.addActionListener(this);
		this.assassinButton2.addActionListener(this);
		
		JPanel heroesPanel1 = new JPanel();
		JPanel heroesPanel2 = new JPanel();
		heroesPanel1.add(new JLabel("Hero 1: "));
		heroesPanel1.add(this.knightButton1);
		heroesPanel1.add(this.orcButton1);
		heroesPanel1.add(this.druidButton1);
		heroesPanel1.add(this.assassinButton1);
		heroesPanel2.add(new JLabel("Hero 2: "));
		heroesPanel2.add(this.knightButton2);
		heroesPanel2.add(this.orcButton2);
		heroesPanel2.add(this.druidButton2);
		heroesPanel2.add(this.assassinButton2);
		heroesPanel1.setLayout(new FlowLayout());
		heroesPanel2.setLayout(new FlowLayout());
		
		JPanel heroesImages = new JPanel();
		heroesImages.add(this.firstHeroImg);
		heroesImages.add(this.firstHero);
		heroesImages.add(new JLabel("  VS  "));
		heroesImages.add(this.secondHero);
		heroesImages.add(this.secondHeroImg);
		
		this.add(heroesPanel1);
		this.add(heroesPanel2);
		this.add(heroesImages);
		this.setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
	}
	
	public void changeFirsHeroName(String newName) {
		this.firstHero.setText(newName);
	}
	public void changeSecondHeroName(String newName) {
		this.secondHero.setText(newName);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==this.knightButton1) {
			this.firstHeroImg.setImage("images/knight.png");
			this.firstHero.setText("<html>VALOROUS<br>ULRIK</html>");
			this.openingWindow.hero1 = new Knight();
		}
		else if(e.getSource()==this.orcButton1) {
			this.firstHeroImg.setImage("images/orc.png");
			this.firstHero.setText("<html>ONE-FANG<br>UGRDUK</html>");
			this.openingWindow.hero1 = new Orc();
		}
		else if(e.getSource()==this.druidButton1) {
			this.firstHeroImg.setImage("images/druid.png");
			this.firstHero.setText("<html>ENLIGHTENED<br>MALIK</html>");
			this.openingWindow.hero1 = new Druid();
		}
		else if(e.getSource()==this.assassinButton1) {
			this.firstHeroImg.setImage("images/assassin.png");
			this.firstHero.setText("<html>ASSASSIN<br>KHELEB</html>");
			this.openingWindow.hero1 = new Assassin();
		}
		else if(e.getSource()==this.knightButton2) {
			this.secondHeroImg.setImage("images/knight.png");
			this.secondHero.setText("<html>VALOROUS<br>ULRIK</html>");
			this.openingWindow.hero2 = new Knight();
		}
		else if(e.getSource()==this.orcButton2) {
			this.secondHeroImg.setImage("images/orc.png");
			this.secondHero.setText("<html>ONE-FANG<br>UGRDUK</html>");
			this.openingWindow.hero2 = new Orc();
		}
		else if(e.getSource()==this.druidButton2) {
			this.secondHeroImg.setImage("images/druid.png");
			this.secondHero.setText("<html>ENLIGHTENED<br>MALIK</html>");
			this.openingWindow.hero2 = new Druid();
		}
		else if(e.getSource()==this.assassinButton2) {
			this.secondHeroImg.setImage("images/assassin.png");
			this.secondHero.setText("<html>ASSASSIN<br>KHELEB</html>");
			this.openingWindow.hero2 = new Assassin();
		}
	}
}

/**
 *
 *  @author Niczyporuk Konrad
 *
 */

import java.awt.FlowLayout;
import java.awt.TextArea;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class TournamentTextPanel extends JPanel{
	
	Hero hero1;
	Hero hero2;
	ImagePanel firstHeroImg;
	ImagePanel secondHeroImg;
	TextArea fightText;
	
	public TournamentTextPanel(Hero hero1, Hero hero2) {
		super();
		this.hero1 = hero1;
		this.hero2 = hero2;
		setSize(850,600);
		
		if(this.hero1.getName().contains("VALOROUS ULRIK")) {
			this.firstHeroImg = new ImagePanel("images/knightFight.png",200,350);
		}
		else if(this.hero1.getName().contains("ONE-FANG UGRDUK")) {
			this.firstHeroImg = new ImagePanel("images/orcFight.png",200,350);
		}
		else if(this.hero1.getName().contains("ENLIGHTENED MALIK")) {
			this.firstHeroImg = new ImagePanel("images/druidFight.png",200,350);
		}
		else if(this.hero1.getName().contains("ASSASSIN KHELEB")) {
			this.firstHeroImg = new ImagePanel("images/assassinFight.png",200,350);
		}
		if(this.hero2.getName().contains("VALOROUS ULRIK")) {
			this.secondHeroImg = new ImagePanel("images/knightFight.png",200,350);
		}
		else if(this.hero2.getName().contains("ONE-FANG UGRDUK")) {
			this.secondHeroImg = new ImagePanel("images/orcFight.png",200,350);
		}
		else if(this.hero2.getName().contains("ENLIGHTENED MALIK")) {
			this.secondHeroImg = new ImagePanel("images/druidFight.png",200,350);
		}
		else if(this.hero2.getName().contains("ASSASSIN KHELEB")) {
			this.secondHeroImg = new ImagePanel("images/assassinFight.png",200,350);
		}
		/*
		 * 
		 */
		this.fightText = new TextArea();
		this.fightText.setEditable(false);
		
		this.add(firstHeroImg);
		this.add(fightText);
		this.add(secondHeroImg);
		
		this.setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
		this.setVisible(true);
	}
}

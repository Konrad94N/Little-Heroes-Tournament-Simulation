/**
 *
 *  @author Niczyporuk Konrad
 *
 */

public class Druid extends Hero{
	protected static int characterCount = 0;
	protected int stamina = 15;
	TournamentTextPanel tournamentTextPanel;
	
	private static final double fullHP = 335;
	
	public Druid() {
		if(this.characterCount!=0) {
			this.name="ENLIGHTENED MALIK "+this.characterCount;
		}
		else {
			this.name="ENLIGHTENED MALIK";
		}
		this.hp=335;
		this.atkMax=55;
		this.atkMin=50;
		this.def=24;
		this.characterCount++;
	}
	
	public int attack(){
		double randVar = Math.random();
		if((randVar>=0.42 && randVar<0.52) || (randVar>=0.0 && randVar<0.1)) {
			tournamentTextPanel.fightText.append(this.name+" missed\n");
			tournamentTextPanel.singleTextAreaText += this.name+" missed<br>";
			return 0;
		}
		int diffAtk = this.atkMax-this.atkMin;
		int Atk = this.atkMin+(int)(((double)diffAtk)*(Math.random()+0.01));
		tournamentTextPanel.fightText.append(this.name+" dealt damage: "+Atk+"\n");
		tournamentTextPanel.singleTextAreaText += this.name+" dealt damage: "+Atk+"<br>";
		return Atk;
	}
	public int defense(int atkOpp) {
		if(this.stamina<=10) {
			this.stamina+=5;
		}
		double randVar = Math.random();
		int atk = (int)(atkOpp*(((double)(100-this.def))/100));
		this.hp-=atk;
		if(randVar>=0.33 && randVar<0.48 && this.stamina>=10 && this.hp<Druid.fullHP) {
			tournamentTextPanel.fightText.append(this.name+" used Wound Healing spell\n");
			tournamentTextPanel.singleTextAreaText += this.name+" used Wound Healing spell<br>";
			this.stamina-=10;
			this.hp+=(int)(0.15*Druid.fullHP);
			if(this.hp>(int)Druid.fullHP) {
				this.hp=(int)Druid.fullHP;
			}
		}
		else if(randVar>=0.5 && randVar<0.6 && this.stamina>=15 && atk!=0){
			tournamentTextPanel.fightText.append(this.name+" used Protective Mist spell and avoided damage\n");
			tournamentTextPanel.singleTextAreaText += this.name+" used Protective Mist spell and avoided damage<br>";
			this.stamina-=15;
			this.hp+=atk;
		}
		if(this.hp<0) {
			this.hp=0;
		}
		return this.hp;
	}
}



/**
 *
 *  @author Niczyporuk Konrad
 *
 */

import java.awt.*;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class OpeningText extends JPanel{
	
	public OpeningText() {
		super();
		
		String textToShow1 = "<html><br>LADIES AND GENTLEMEN!<br>HUMANS AND MONSTERS!<br>LETS BEGIN THE GAME!<br></html>";
		String textToShow2 = "<html><br>---------------------------------------------------------------------------<br>CHOOSE TWO OUT OF OUR HEROES<br><br>[1] VALOROUS ULRIK [KNIGHT] - HP [400] / ATK [42-64] / DEF [37]<br>[2] ONE-FANG UGRDUK [ORC] - HP [450] / ATK [30-80] / DEF [15]<br>[3] ENLIGHTENED MALIK [DRUID] - HP [335] / ATK [50-55] / DEF [24]<br>[4] ASSASSIN KHELEB [PALADIN] - HP [370] / ATK [37-73] / DEF [32]<br></html>";
		String textToShow3 = "<html><br>---------------------------------------------------------------------------<br><br>**** Knight ****<br>- Light Attack (20% chance for cumulative sword attack with 200% power)<br><br>**** Orc ****<br>- Fury (10% chance for chaotic axe attack with 260% power)<br><br>**** Druid ****<br>- Wounds Healing (15% chance for healing 20% from max HP points or <br>(if less needed) all points remaining to full HP)<br>- Protective Mist (10% chace for avoiding damage in current round)<br><br>**** Assassin ****<br>- Sudden Attack (30% chance for stab with hidden dagger.<br>Deals extra wounds of 35% MAX attack during 3 next rounds)<br>---------------------------------------------------------------------------<br></html>";
		String textToShow4 = "<html><br>WHO DO YOU CHOOSE?<br><br></html>";
		
		JLabel text1 = new JLabel(textToShow1);
		JLabel text2 = new JLabel(textToShow2);
		JLabel text3 = new JLabel(textToShow3);
		JLabel text4 = new JLabel(textToShow4);
		
		text1.setFont(new Font("Verdana",1,13));
		text2.setFont(new Font("Verdana",0,13));
		text3.setFont(new Font("Verdana",0,13));
		text4.setFont(new Font("Verdana",1,15));
		
		this.add(text1);
		this.add(text2);
		this.add(text3);
		this.add(text4);
		
		this.setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
		this.setSize(500,600);
	}
}

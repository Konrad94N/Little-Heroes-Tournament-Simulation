/**
 *
 *  @author Niczyporuk Konrad
 *
 */

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.MediaTracker;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class ImagePanel extends JPanel{
	
	private BufferedImage image;
	
	public ImagePanel(String imgPath, int imgWidth, int imgHeight) {
		super();
		
		File imageFile = new File(imgPath);
		try {
			this.image = ImageIO.read(imageFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/*
		 * You can't see an Image without this part - image need to have any size
		 */
		Dimension dim = new Dimension(imgWidth, imgHeight);
		this.setPreferredSize(dim);
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2d = (Graphics2D)g;
		g2d.drawImage(this.image,0,0,this);
	}
	
	public void setImage(String imgPath) {
		File imageFile = new File(imgPath);
		try {
			this.image = ImageIO.read(imageFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		repaint();
	}
	
	public BufferedImage getImg() {
		return this.image;
	}
}
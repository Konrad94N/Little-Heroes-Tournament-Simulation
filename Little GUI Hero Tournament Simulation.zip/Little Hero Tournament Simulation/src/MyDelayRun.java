
public class MyDelayRun implements Runnable{
	OpeningWindow openingWindow;
	
	public MyDelayRun(OpeningWindow openingWindow) {
		this.openingWindow = openingWindow;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		this.openingWindow.clashFrame.clash();
	}

}

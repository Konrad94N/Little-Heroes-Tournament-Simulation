/**
 *
 *  @author Niczyporuk Konrad
 *
 */

public class Hero {
	protected String name;
	protected int hp;
	protected int atkMax;
	protected int atkMin;
	protected int def;
	
	public int attack(){
		return 0;
	}
	public int defense(int atkOpp) {
		return this.hp;
	}
	
	public String getName() {
		return this.name;
	}
}


/**
 *
 *  @author Niczyporuk Konrad
 *
 */

public class Assassin extends Hero{
	protected static int characterCount = 0;	
	protected int stabCount=0;
	TournamentTextPanel tournamentTextPanel;
	
	public Assassin() {
		
		if(this.characterCount!=0) {
			this.name="ASSASSIN KHELEB "+this.characterCount;
		}
		else {
			this.name="ASSASSIN KHELEB";
		}
		this.hp=370;
		this.atkMax=73;
		this.atkMin=37;
		this.def=32;
		this.characterCount++;
	}
	
	public int attack(){
		double randVar = Math.random();
		if((randVar>=0.25 && randVar<0.35) || (randVar>=0.64 && randVar<0.74)) {
			if(this.stabCount!=0) {
				tournamentTextPanel.fightText.append(this.name+" missed, but the opponent sustains extra damage "+(int)(((double)this.atkMax)*0.35)+" from stab\n");
				tournamentTextPanel.singleTextAreaText += this.name+" missed, but the opponent sustains extra damage "+(int)(((double)this.atkMax)*0.35)+" from stab<br>";
				if((this.stabCount++)==3) {
					this.stabCount=0;
				}
				return (int)(((double)this.atkMax)*0.35);
			}
			tournamentTextPanel.fightText.append(this.name+" missed\n");
			tournamentTextPanel.singleTextAreaText += this.name+" missed<br>";
			return 0;
		}
		int diffAtk = this.atkMax-this.atkMin;
		int Atk = this.atkMin+(int)(((double)diffAtk)*(Math.random()+0.01));
		if(this.stabCount==0 && randVar<0.30) {
			this.stabCount=1;
			tournamentTextPanel.fightText.append(this.name+" stabbed opponent with hidden dagger\n");
			tournamentTextPanel.singleTextAreaText += this.name+" stabbed opponent with hidden dagger<br>";
		}
		if(this.stabCount!=0) {
			tournamentTextPanel.fightText.append(this.name+" dealt damage "+Atk+" with extra wounds "+(int)(((double)this.atkMax)*0.35)+" from stab\n");
			tournamentTextPanel.singleTextAreaText += this.name+" dealt damage "+Atk+" with extra wounds "+(int)(((double)this.atkMax)*0.35)+" from stab<br>";
			if((this.stabCount++)==3) {
				this.stabCount=0;
			}
			return Atk+(int)(((double)this.atkMax)*0.35);
		}
		tournamentTextPanel.fightText.append(this.name+" dealt damage "+Atk+"\n");
		tournamentTextPanel.singleTextAreaText += this.name+" dealt damage "+Atk+"<br>";
		return Atk;
	}
	public int defense(int atkOpp) {
		int atk = (int)(atkOpp*(((double)(100-this.def))/100));
		this.hp-=atk;
		if(this.hp<0) {
			this.hp=0;
		}
		return this.hp;
	}
}


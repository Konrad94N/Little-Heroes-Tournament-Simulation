/**
 *
 *  @author Niczyporuk Konrad
 *
 */

public class Knight extends Hero{
protected static int characterCount = 0;
TournamentTextPanel tournamentTextPanel;

	public Knight() {
		if(this.characterCount!=0) {
			this.name="VALOROUS ULRIK "+this.characterCount;
		}
		else {
			this.name="VALOROUS ULRIK";
		}
		this.hp=400;
		this.atkMax=64;
		this.atkMin=42;
		this.def=37;
		this.characterCount++;
	}
	
	public int attack(){
		double randVar = Math.random();
		if((randVar>=0.52 && randVar<0.62) || (randVar>=0.9 && randVar<1)) {
			tournamentTextPanel.fightText.append(this.name+" missed\n");
			tournamentTextPanel.singleTextAreaText += this.name+" missed<br>";
			return 0;
		}
		int diffAtk = this.atkMax-this.atkMin;
		int Atk = this.atkMin+(int)(((double)diffAtk)*(Math.random()+0.01));
		if(randVar>=0.72 && randVar<0.92) {
			tournamentTextPanel.fightText.append(this.name+" dealt Light Attack "+(int)(Atk*2)+"\n");
			tournamentTextPanel.singleTextAreaText += this.name+" dealt Light Attack "+(int)(Atk*2)+"<br>";
			return (int)(Atk*2);
		}
		tournamentTextPanel.fightText.append(this.name+" dealt damage "+Atk+"\n");
		tournamentTextPanel.singleTextAreaText += this.name+" dealt damage "+Atk+"<br>";
		return Atk;
	}
	public int defense(int atkOpp) {
		int atk = (int)(atkOpp*(((double)(100-this.def))/100));
		this.hp-=atk;
		if(this.hp<0) {
			this.hp=0;
		}
		return this.hp;
	}
}

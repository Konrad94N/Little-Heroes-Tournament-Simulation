
/**
 *
 *  @author Niczyporuk Konrad
 *
 */

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.swing.*;

public class OpeningWindow extends JFrame implements ActionListener{
	
	OpeningText openingText;
	HeroesToChoose heroesToChoose;
	ClashFrame clashFrame;
	JButton startButton = new JButton("FIGHT");
	Hero hero1 = null;
	Hero hero2 = null;
	
	public OpeningWindow(){
		super("Hero Tournament");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(500,600);
		this.setResizable(false);
		setLocation(700,100);
		
		/*
		 * Creating Panels
		 */
		this.openingText = new OpeningText();
		this.heroesToChoose = new HeroesToChoose(this);
		this.startButton.addActionListener(this);
		
		/*
		 * Adding Panels
		 */
		this.add(openingText,BorderLayout.PAGE_START);
		this.add(heroesToChoose,BorderLayout.LINE_START);
		this.add(startButton, BorderLayout.SOUTH);
		
		/*
		 * Final lines
		 */
		this.pack();
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==this.startButton) {
			this.setVisible(false);
			if(this.clashFrame==null) {
				this.clashFrame  = new ClashFrame(this);
			}
			if(this.hero1.getName().contains("VALOROUS ULRIK")) {
				((Knight)this.hero1).tournamentTextPanel = this.clashFrame.tournamentTextPanel;
			}
			else if(this.hero1.getName().contains("ONE-FANG UGRDUK")) {
				((Orc)this.hero1).tournamentTextPanel = this.clashFrame.tournamentTextPanel;
			}
			else if(this.hero1.getName().contains("ENLIGHTENED MALIK")) {
				((Druid)this.hero1).tournamentTextPanel = this.clashFrame.tournamentTextPanel;
			}
			else if(this.hero1.getName().contains("ASSASSIN KHELEB")) {
				((Assassin)this.hero1).tournamentTextPanel = this.clashFrame.tournamentTextPanel;
			}
			if(this.hero2.getName().contains("VALOROUS ULRIK")) {
				((Knight)this.hero2).tournamentTextPanel = this.clashFrame.tournamentTextPanel;
			}
			else if(this.hero2.getName().contains("ONE-FANG UGRDUK")) {
				((Orc)this.hero2).tournamentTextPanel = this.clashFrame.tournamentTextPanel;
			}
			else if(this.hero2.getName().contains("ENLIGHTENED MALIK")) {
				((Druid)this.hero2).tournamentTextPanel = this.clashFrame.tournamentTextPanel;
			}
			else if(this.hero2.getName().contains("ASSASSIN KHELEB")) {
				((Assassin)this.hero2).tournamentTextPanel = this.clashFrame.tournamentTextPanel;
			}
			this.clashFrame.setTournamentTextPanel(this.hero1, this.hero2);
			this.clashFrame.continuePanel.setVisible(false);
			this.clashFrame.setVisible(true);
			this.clashFrame.tournamentTextPanel.fightText.setVisible(false);
			/*
			 * Special function to Delay the clash awakening before all the images will Load
			 */
			final ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(1);
			executor.schedule(new MyDelayRun(this), 1, TimeUnit.SECONDS);
		}
	}
}

/**
 *
 *  @author Niczyporuk Konrad
 *
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ContinuePanel extends JPanel implements ActionListener{
	
	JButton yesButton;
	JButton noButton;
	ClashFrame clashFrame;
	
	public ContinuePanel(ClashFrame clashFrame) {
		super();
		this.setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
		this.clashFrame = clashFrame;
		
		/*
		 * Create elements
		 */
		JLabel continueText = new JLabel("DO YOU WANT ANOTHER FIGHT?  --  ");
		this.yesButton = new JButton("YES");
		this.noButton = new JButton("NO");
		
		/*
		 * Action Listeners
		 */
		this.yesButton.addActionListener(this);
		this.noButton.addActionListener(this);
		
		/*
		 * Add elements
		 */
		this.add(continueText);
		this.add(this.yesButton);
		this.add(this.noButton);
		
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==this.yesButton) {
			this.clashFrame.openingWindow.heroesToChoose.firstHeroImg.setImage("images/questionMark.png");
			this.clashFrame.openingWindow.heroesToChoose.secondHeroImg.setImage("images/questionMark.png");
			this.clashFrame.setVisible(false);
			this.clashFrame.openingWindow.setVisible(true);
		}
		else if(e.getSource()==this.noButton) {
			this.clashFrame.dispatchEvent(new WindowEvent(this.clashFrame, WindowEvent.WINDOW_CLOSING));
		}
	}

}

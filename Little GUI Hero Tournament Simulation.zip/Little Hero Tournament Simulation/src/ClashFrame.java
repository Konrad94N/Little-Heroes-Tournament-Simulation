/**
 *
 *  @author Niczyporuk Konrad
 *
 */

import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.event.ActionListener;
import java.util.Timer;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ClashFrame extends JFrame{

	OpeningWindow openingWindow;
	TournamentTextPanel tournamentTextPanel = null;
	ContinuePanel continuePanel;
	Timer timer;
	
	public ClashFrame(OpeningWindow openingWindow) {
		super("--> CLASH <--");
		this.openingWindow = openingWindow;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(850,500);
		setLocation(550,250);
		setLayout(new FlowLayout(FlowLayout.CENTER));
		this.setResizable(false);
		
		/*
		 * Creating Panels
		 */
		this.tournamentTextPanel = new TournamentTextPanel(this.openingWindow.hero1, this.openingWindow.hero2);
		this.continuePanel = new ContinuePanel(this);
		
		/*
		 * Adding Panels
		 */
		this.add(tournamentTextPanel);
		this.add(continuePanel);	
	}
	
	public void setTournamentTextPanel(Hero hero1, Hero hero2) {
		if(this.tournamentTextPanel==null) {
			this.tournamentTextPanel = new TournamentTextPanel(hero1, hero2);
		}
		else {
			if(hero1.getName().contains("VALOROUS ULRIK")) {
				this.tournamentTextPanel.firstHeroImg.setImage("images/knightFight.png");
			}
			else if(hero1.getName().contains("ONE-FANG UGRDUK")) {
				this.tournamentTextPanel.firstHeroImg.setImage("images/orcFight.png");
			}
			else if(hero1.getName().contains("ENLIGHTENED MALIK")) {
				this.tournamentTextPanel.firstHeroImg.setImage("images/druidFight.png");
			}
			else if(hero1.getName().contains("ASSASSIN KHELEB")) {
				this.tournamentTextPanel.firstHeroImg.setImage("images/assassinFight.png");
			}
			if(hero2.getName().contains("VALOROUS ULRIK")) {
				this.tournamentTextPanel.secondHeroImg.setImage("images/knightFight.png");
			}
			else if(hero2.getName().contains("ONE-FANG UGRDUK")) {
				this.tournamentTextPanel.secondHeroImg.setImage("images/orcFight.png");
			}
			else if(hero2.getName().contains("ENLIGHTENED MALIK")) {
				this.tournamentTextPanel.secondHeroImg.setImage("images/druidFight.png");
			}
			else if(hero2.getName().contains("ASSASSIN KHELEB")) {
				this.tournamentTextPanel.secondHeroImg.setImage("images/assassinFight.png");
			}
		}
	}
	
	public void clash() {
		this.tournamentTextPanel.fightText.setText("");
		this.tournamentTextPanel.fightText.append(
		"\n---------------------------------------------------------------------\n"+
		"ALEA IACTA EST!\n"+
		"LETS BEGIN THE CLASH!\n"+
		"---------------------------------------------------------------------\n\n"
		);
		try
		{
		    Thread.sleep(2000);
		}
		catch(InterruptedException ex)
		{
		    Thread.currentThread().interrupt();
		}
		String fightPoint="fight";
		while(fightPoint=="fight") {
			this.tournamentTextPanel.fightText.append("-----> ROUND "+Fight.round+" <-----\n\n");
			this.tournamentTextPanel.singleTextAreaText = "<html><br>---------------------------------- ROUND "+Fight.round+" ----------------------------------<br><br>";
			fightPoint=Fight.fight(this.openingWindow.hero1, this.openingWindow.hero2, this.tournamentTextPanel);
			if(fightPoint=="fight") {
				try
				{
				    Thread.sleep(4300);
				}
				catch(InterruptedException ex)
				{
				    Thread.currentThread().interrupt();
				}
			}
			else if(fightPoint=="draw") {
				this.tournamentTextPanel.fightText.append("Both Heroes fell in equal fight!\n");
				this.tournamentTextPanel.singleTextArea.setVisible(false);
				this.tournamentTextPanel.fightText.setVisible(true);
				this.setCharCount(this.openingWindow.hero1);
				this.setCharCount(this.openingWindow.hero2);
				this.continuePanel.setVisible(true);
				this.repaint();
			}
			else if(fightPoint=="1") {
				this.tournamentTextPanel.fightText.append(this.openingWindow.hero1.name+" has won!\nPRAISE THE WINNER!\n");
				this.tournamentTextPanel.singleTextArea.setVisible(false);
				this.tournamentTextPanel.fightText.setVisible(true);
				this.setCharCount(this.openingWindow.hero1);
				this.setCharCount(this.openingWindow.hero2);
				this.continuePanel.setVisible(true);
				this.repaint();
			}
			else if(fightPoint=="2"){
				this.tournamentTextPanel.fightText.append(this.openingWindow.hero2.name+" has won!\nPRAISE THE WINNER!\n");
				this.tournamentTextPanel.singleTextArea.setVisible(false);
				this.tournamentTextPanel.fightText.setVisible(true);
				this.setCharCount(this.openingWindow.hero1);
				this.setCharCount(this.openingWindow.hero2);
				this.continuePanel.setVisible(true);
				this.repaint();
			}
		}
	}
	
	public static void setCharCount(Hero hero) {

		if(hero.name.contains("VALOROUS")) {
			((Knight)hero).characterCount=0;
		}
		else if(hero.name.contains("UGRDUK")) {
			((Orc)hero).characterCount=0;
		}
		else if(hero.name.contains("MALIK")) {
			((Druid)hero).characterCount=0;
		}
		else if(hero.name.contains("ASSASSIN")){
			((Assassin)hero).characterCount=0;
		}
	}

}

/**
 *
 *  @author Niczyporuk Konrad
 *
 */

import java.awt.EventQueue;
import java.util.Scanner;

public class Tournament {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				new OpeningWindow();
			}
		});
	}
}

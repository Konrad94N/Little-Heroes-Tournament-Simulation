#!/bin/bash

java -cp Tournament.jar Tournament
